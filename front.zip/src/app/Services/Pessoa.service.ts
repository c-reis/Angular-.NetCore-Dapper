import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pessoa } from '../Models/Pessoa';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PessoaService {

  private url = `${environment.mainUrlAPI}/pessoa`;

  constructor(private http: HttpClient) { }

  getPessoas(): Observable<Pessoa[]> {
    return this.http.get<Pessoa[]>(this.url);
  }

  CreatePessoa(request: Pessoa): Observable<Pessoa> {
    return this.http.post<Pessoa>(this.url, request);
  }

  getPessoaById(id: number): Observable<Pessoa> {
    const _url = `${this.url}/${id}`
    return this.http.get<Pessoa>(_url);
  }

  updatePessoa(id: number, request: Pessoa): Observable<Pessoa> {
    const _url = `${this.url}/${id}`
    return this.http.put<Pessoa>(_url, request);
  }

  deletePessoa(id: number): Observable<any> {
    const _url = `${this.url}/${id}`
    return this.http.delete<any>(_url);
  }

}
