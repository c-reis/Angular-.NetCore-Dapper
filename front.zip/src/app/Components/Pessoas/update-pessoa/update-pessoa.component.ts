import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Pessoa } from 'src/app/Models/Pessoa';
import { PessoaService } from 'src/app/Services/Pessoa.service';

@Component({
  selector: 'app-update-pessoa',
  templateUrl: './update-pessoa.component.html',
  styleUrls: ['./update-pessoa.component.css']
})
export class UpdatePessoaComponent implements OnInit {

  id: any;
  request!: Pessoa;
  response!: string;

  constructor(private pessoaService: PessoaService, private route: ActivatedRoute, private _route: Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    this.pessoaService.getPessoaById(this.id).subscribe(res => {
      this.request = {
        nomecompleto: res.nomecompleto,
        idade: res.idade,
        cpf: res.cpf,
        rua_endereco: res.rua_endereco,
        num_endereco: res.num_endereco,
        bairro_endereco: res.bairro_endereco,
        cidade: res.cidade
      }
    });
  }

  update() {
    this.pessoaService.updatePessoa(this.id, this.request).subscribe(res => {
      alert("Dados atualizado com sucesso!")
      this._route.navigate(['/pessoas']);
    });
  }

  cancel() {
    this._route.navigate(['/pessoas']);
  }
}
