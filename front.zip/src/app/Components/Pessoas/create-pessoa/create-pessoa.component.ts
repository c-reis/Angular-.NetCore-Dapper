import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pessoa } from 'src/app/Models/Pessoa';
import { PessoaService } from 'src/app/Services/Pessoa.service';

@Component({
  selector: 'app-create-pessoa',
  templateUrl: './create-pessoa.component.html',
  styleUrls: ['./create-pessoa.component.css']
})
export class CreatePessoaComponent implements OnInit {

  request: Pessoa = {
    nomecompleto: '',
    idade: 0,
    cpf: '',
    rua_endereco: '',
    num_endereco: 0,
    bairro_endereco: '',
    cidade: ''
  };

  response: any;

  constructor(private pessoaService: PessoaService, private _route: Router) { }

  ngOnInit() {
  }

  save() {
    this.pessoaService.CreatePessoa(this.request).subscribe(res => {
      this.response = res;
      alert("Cadastro realizado com sucesso!");
      this._route.navigate(['/pessoas']);
    });
  }

  cancel() {
    this._route.navigate(['/pessoas']);
  }

}
