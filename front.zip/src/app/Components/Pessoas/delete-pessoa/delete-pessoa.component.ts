import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscriber } from 'rxjs';
import { Pessoa } from 'src/app/Models/Pessoa';
import { PessoaService } from 'src/app/Services/Pessoa.service';

@Component({
  selector: 'app-delete-pessoa',
  templateUrl: './delete-pessoa.component.html',
  styleUrls: ['./delete-pessoa.component.css']
})
export class DeletePessoaComponent implements OnInit {

  id: any;
  request!: Pessoa;

  constructor(private pessoaService: PessoaService, private route: ActivatedRoute, private _route: Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    this.pessoaService.getPessoaById(this.id).subscribe(res => {
      this.request = {
        nomecompleto: res.nomecompleto,
        idade: res.idade,
        cpf: res.cpf,
        rua_endereco: res.rua_endereco,
        num_endereco: res.num_endereco,
        bairro_endereco: res.bairro_endereco,
        cidade: res.cidade
      }
    });
  }

  delete() {
    this.pessoaService.deletePessoa(this.id).subscribe(res => {
      alert("Removido com sucesso!");
      this._route.navigate(['/pessoas']);
    });
  }

  cancel() {
    this._route.navigate(['/pessoas']);
  }

}
