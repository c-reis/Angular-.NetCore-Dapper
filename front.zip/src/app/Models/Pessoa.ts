export interface Pessoa {
    idpessoa?: number;
    nomecompleto: string;
    idade: number;
    cpf: string;
    rua_endereco: string;
    num_endereco: number;
    bairro_endereco: string;
    cidade: string;
}