import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreatePessoaComponent } from './Components/Pessoas/create-pessoa/create-pessoa.component';
import { DeletePessoaComponent } from './Components/Pessoas/delete-pessoa/delete-pessoa.component';
import { PessoasComponent } from './Components/Pessoas/Pessoas.component';
import { UpdatePessoaComponent } from './Components/Pessoas/update-pessoa/update-pessoa.component';

const routes: Routes = [
  { path: 'pessoas', component: PessoasComponent },
  { path: 'pessoas/create', component: CreatePessoaComponent },
  { path: 'pessoas/update/:id', component: UpdatePessoaComponent },
  { path: 'pessoas/delete/:id', component: DeletePessoaComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
