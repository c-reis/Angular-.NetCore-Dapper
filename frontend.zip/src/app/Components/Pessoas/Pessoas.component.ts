import { Component, OnInit } from '@angular/core';
import { Pessoa } from '../../Models/Pessoa';
import { PessoaService } from 'src/app/Services/Pessoa.service';

@Component({
  selector: 'app-Pessoas',
  templateUrl: './Pessoas.component.html',
  styleUrls: ['./Pessoas.component.css']
})
export class PessoasComponent implements OnInit {

  responsePessoas!: Pessoa[];

  constructor(private pessoaService: PessoaService) { }

  ngOnInit() {
    this.pessoaService.getPessoas().subscribe(res => this.responsePessoas = res)
  }

}
